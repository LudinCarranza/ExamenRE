rootProject.name = "LabEquipmentManager"
include(":app")
