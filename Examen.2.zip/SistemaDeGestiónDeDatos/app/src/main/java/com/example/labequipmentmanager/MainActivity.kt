package com.example.labequipmentmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.labequipmentmanager.ui.theme.LabEquipmentManagerTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.MaterialTheme
import com.example.labequipmentmanager.ui.screens.AppNavHost

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            LabEquipmentManagerTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    AppNavHost()
                }
            }
        }
    }
}
