package com.example.labequipmentmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.labequipmentmanager.repository.FirebaseRepository

@Composable
fun StudentLoansScreen() {
    val repo = remember { FirebaseRepository() }
    var loans by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        // In a real app we would pass current UID; here it's placeholder
        loading = true
        loans = listOf()
        loading = false
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Mis préstamos", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(8.dp))
        if (loading) CircularProgressIndicator() else {
            LazyColumn {
                items(loans) { loan ->
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(loan["equipmentName"] as? String ?: "")
                            Text("Estado: ${loan["status"] as? String ?: ""}")
                        }
                    }
                }
            }
        }
    }
}
