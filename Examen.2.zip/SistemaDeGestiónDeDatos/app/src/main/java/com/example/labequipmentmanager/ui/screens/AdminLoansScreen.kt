package com.example.labequipmentmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.labequipmentmanager.repository.FirebaseRepository

@Composable
fun AdminLoansScreen(navController: NavController) {
    val repo = remember { FirebaseRepository() }
    var loans by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    var loading by remember { mutableStateOf(true) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        loading = true
        loans = repo.getAllLoans()
        loading = false
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Préstamos", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(8.dp))
        if (loading) CircularProgressIndicator() else {
            LazyColumn {
                items(loans) { loan ->
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(loan["equipmentName"] as? String ?: "")
                            Text("Alumno: ${loan["studentUsername"] as? String ?: ""}")
                            Text("Estado: ${loan["status"] as? String ?: ""}")
                            Spacer(modifier = Modifier.height(8.dp))
                            Row {
                                Button(onClick = { 
                                    val id = loan["id"] as String
                                    scope.launch { repo.updateLoanStatus(id, "APROBADO") }
                                }) { Text("Aprobar") }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(onClick = {
                                    val id = loan["id"] as String
                                    scope.launch { repo.updateLoanStatus(id, "DEVUELTO") }
                                }) { Text("Marcar devuelto") }
                            }
                        }
                    }
                }
            }
        }
    }
}
