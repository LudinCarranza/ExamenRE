package com.example.labequipmentmanager.repository

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.tasks.await
import java.util.*

data class FireUser(val uid: String = "", val username: String = "", val role: String = "student")

class FirebaseRepository {
    private val auth: FirebaseAuth = Firebase.auth
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()

    // Auth
    suspend fun register(email: String, password: String, username: String, role: String): FireUser {
        val result = auth.createUserWithEmailAndPassword(email, password).await()
        val uid = result.user?.uid ?: throw Exception("No se pudo crear usuario")
        val user = FireUser(uid = uid, username = username, role = role)
        db.collection("users").document(uid).set(user).await()
        return user
    }

    suspend fun login(email: String, password: String): FireUser {
        val result = auth.signInWithEmailAndPassword(email, password).await()
        val uid = result.user?.uid ?: throw Exception("No se pudo autenticar")
        val doc = db.collection("users").document(uid).get().await()
        return doc.toObject(FireUser::class.java) ?: throw Exception("Usuario no encontrado en Firestore")
    }

    fun logout() { auth.signOut() }

    // Equipos
    suspend fun getAllEquipments(): List<Map<String, Any>> {
        val snapshot = db.collection("equipos").get().await()
        return snapshot.documents.map { it.data!! + mapOf("id" to it.id) }
    }

    suspend fun addEquipment(name: String, description: String, imageUrl: String?) {
        val data = hashMapOf(
            "name" to name,
            "description" to description,
            "imageUrl" to (imageUrl ?: ""),
            "available" to true,
            "requestsCount" to 0
        )
        db.collection("equipos").add(data).await()
    }

    // Préstamos
    suspend fun requestLoan(equipmentId: String, equipmentName: String, studentUid: String, studentUsername: String, days: Int = 3) {
        val now = Date()
        val due = Date(now.time + days * 24L * 3600L * 1000L)
        val loan = hashMapOf(
            "equipmentId" to equipmentId,
            "equipmentName" to equipmentName,
            "studentUid" to studentUid,
            "studentUsername" to studentUsername,
            "startDate" to now,
            "dueDate" to due,
            "status" to "PENDIENTE"
        )
        db.collection("prestamos").add(loan).await()
        // incrementar contador de requests
        val ref = db.collection("equipos").document(equipmentId)
        db.runTransaction { tx ->
            val snap = tx.get(ref)
            val curr = snap.getLong("requestsCount") ?: 0L
            tx.update(ref, "requestsCount", curr + 1)
        }.await()
    }

    suspend fun getLoansForStudent(uid: String) = db.collection("prestamos").whereEqualTo("studentUid", uid).get().await().documents.map { it.data!! + mapOf("id" to it.id) }

    suspend fun getAllLoans() = db.collection("prestamos").get().await().documents.map { it.data!! + mapOf("id" to it.id) }

    suspend fun updateLoanStatus(loanId: String, status: String) { db.collection("prestamos").document(loanId).update("status", status).await() }

    suspend fun setEquipmentAvailability(equipmentId: String, available: Boolean) { db.collection("equipos").document(equipmentId).update("available", available).await() }

    suspend fun getTopRequestedEquipments(limit: Long = 5) = db.collection("equipos").orderBy("requestsCount", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(limit).get().await().documents.map { it.data!! + mapOf("id" to it.id) }
}
