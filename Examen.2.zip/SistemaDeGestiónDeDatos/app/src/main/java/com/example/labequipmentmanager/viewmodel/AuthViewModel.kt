package com.example.labequipmentmanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.labequipmentmanager.repository.FirebaseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

sealed class AuthState {
    object Idle : AuthState()
    data class Success(val uid: String, val username: String, val role: String) : AuthState()
    data class Error(val message: String) : AuthState()
    object Loading : AuthState()
}

class AuthViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = FirebaseRepository()

    private val _state = MutableStateFlow<AuthState>(AuthState.Idle)
    val state: StateFlow<AuthState> = _state

    fun register(email: String, password: String, username: String, role: String) {
        viewModelScope.launch {
            _state.value = AuthState.Loading
            try {
                val u = repo.register(email, password, username, role)
                _state.value = AuthState.Success(u.uid, u.username, u.role)
            } catch (e: Exception) {
                _state.value = AuthState.Error(e.message ?: "Error desconocido")
            }
        }
    }

    fun login(email: String, password: String) {
        viewModelScope.launch {
            _state.value = AuthState.Loading
            try {
                val u = repo.login(email, password)
                _state.value = AuthState.Success(u.uid, u.username, u.role)
            } catch (e: Exception) {
                _state.value = AuthState.Error(e.message ?: "Usuario o contraseña incorrectos")
            }
        }
    }

    fun logout() { repo.logout(); _state.value = AuthState.Idle }

    fun reset() { _state.value = AuthState.Idle }
}
