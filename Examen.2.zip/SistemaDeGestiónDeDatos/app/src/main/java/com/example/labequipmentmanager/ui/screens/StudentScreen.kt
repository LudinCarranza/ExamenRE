package com.example.labequipmentmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun StudentScreen(navController: NavController) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Panel de Estudiante", style = MaterialTheme.typography.h5)
        Spacer(modifier = Modifier.height(8.dp))
        Text("Aquí podrás ver equipos disponibles y solicitar préstamos.")
        Spacer(modifier = Modifier.height(16.dp))
        Button(onClick = { navController.navigate("catalog") }) { Text("Ver catálogo") }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { navController.navigate("student_loans") }) { Text("Mis préstamos") }
    }
}
