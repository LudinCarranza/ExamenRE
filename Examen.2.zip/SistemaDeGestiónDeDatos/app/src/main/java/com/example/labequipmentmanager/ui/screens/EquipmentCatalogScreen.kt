package com.example.labequipmentmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.labequipmentmanager.repository.FirebaseRepository
import kotlinx.coroutines.launch

@Composable
fun EquipmentCatalogScreen(navController: NavController) {
    val repo = remember { FirebaseRepository() }
    val scope = rememberCoroutineScope()
    var items by remember { mutableStateOf(listOf<Map<String, Any>>()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        loading = true
        items = repo.getAllEquipments()
        loading = false
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Catálogo de Equipos", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(8.dp))
        if (loading) {
            CircularProgressIndicator()
        } else {
            LazyColumn {
                items(items) { eq ->
                    Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(eq["name"] as? String ?: "")
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(eq["description"] as? String ?: "")
                            Spacer(modifier = Modifier.height(8.dp))
                            Row {
                                Text(if (eq["available"] as? Boolean == true) "Disponible" else "No disponible")
                                Spacer(modifier = Modifier.weight(1f))
                                Button(onClick = {
                                    // requesting loan (simplified) - in real app need current user info
                                }, enabled = eq["available"] as? Boolean == true) {
                                    Text("Solicitar Préstamo")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
